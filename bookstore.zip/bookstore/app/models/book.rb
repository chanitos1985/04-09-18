class Book < ApplicationRecord
end


